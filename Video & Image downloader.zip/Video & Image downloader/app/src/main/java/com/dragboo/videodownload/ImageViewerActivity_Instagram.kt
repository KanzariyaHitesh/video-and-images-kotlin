package com.dragboo.videodownload

import android.app.ProgressDialog
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.github.chrisbanes.photoview.PhotoView
import com.unity3d.ads.UnityAds

class ImageViewerActivity_Instagram : AppCompatActivity() {
    internal var path: String? = null
    internal lateinit var mPhotoView: PhotoView
    private var progressDialog: ProgressDialog? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.i_activity_image_viewer)

        progressDialog = ProgressDialog(this)
        progressDialog!!.setCancelable(true)
        progressDialog!!.setMessage("showing Ad...")
        progressDialog!!.show()


        Handler().postDelayed({
            if (UnityAds.isReady("video")) {
                UnityAds.show(this@ImageViewerActivity_Instagram, "video")
                progressDialog!!.dismiss()
            } else {
                progressDialog!!.dismiss()
            }
        }, 10000)

        try {
            path = intent.extras!!.getString("path")
        } catch (e: NullPointerException) {
            Toast.makeText(this, getString(R.string.imageviewer_error), Toast.LENGTH_SHORT).show()
        }

        mPhotoView = findViewById(R.id.imageviewer)
        mPhotoView.setImageURI(Uri.parse(path))
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
}