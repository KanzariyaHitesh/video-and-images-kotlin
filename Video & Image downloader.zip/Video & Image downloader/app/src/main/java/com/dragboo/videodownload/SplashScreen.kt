package com.dragboo.videodownload

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.RelativeLayout

import androidx.appcompat.app.AppCompatActivity

import com.dragboo.videodownload.update.ApiClient
import com.dragboo.videodownload.update.ApiInterface
import com.dragboo.videodownload.update.ResponseData
import com.unity3d.ads.IUnityAdsListener
import com.unity3d.ads.UnityAds

import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class SplashScreen : AppCompatActivity() {

    internal lateinit var button1: Button
    internal lateinit var button2: Button
    internal lateinit var relativeLayout: RelativeLayout

    private inner class UnityAdListener : IUnityAdsListener {
        override fun onUnityAdsReady(s: String) {
            Log.e("Unity Ready", s)
        }

        override fun onUnityAdsStart(s: String) {
            Log.e("Unity Start", s)
        }

        override fun onUnityAdsFinish(s: String, finishState: UnityAds.FinishState) {
            Log.e("Unity Finish", s + "\n" + finishState.toString())
        }

        override fun onUnityAdsError(unityAdsError: UnityAds.UnityAdsError, s: String) {
            Log.e("Unity Error", unityAdsError.toString() + "\n" + s)
        }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash_screen)
        //        getWindow().setFlags(1024,1024);

        val unityAdListener = UnityAdListener()
        UnityAds.initialize(this, getString(R.string.unity_id), unityAdListener)

        button1 = findViewById<View>(R.id.yes_btn) as Button
        button2 = findViewById<View>(R.id.no_btn) as Button
        relativeLayout = findViewById<View>(R.id.update_lay) as RelativeLayout
        val connec = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        if (connec.getNetworkInfo(0)!!.state == android.net.NetworkInfo.State.CONNECTED ||
                connec.getNetworkInfo(0)!!.state == android.net.NetworkInfo.State.CONNECTING ||
                connec.getNetworkInfo(1)!!.state == android.net.NetworkInfo.State.CONNECTING ||
                connec.getNetworkInfo(1)!!.state == android.net.NetworkInfo.State.CONNECTED) {
            update()
            button1.setOnClickListener {
                val uri = Uri.parse("market://details?id=$packageName")
                val goToMarket = Intent(Intent.ACTION_VIEW, uri)
                goToMarket.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY or Intent.FLAG_ACTIVITY_NEW_DOCUMENT or Intent.FLAG_ACTIVITY_MULTIPLE_TASK)
                try {
                    startActivity(goToMarket)
                } catch (e: ActivityNotFoundException) {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("http://play.google.com/store/apps/details?id=$packageName")))
                }
            }
            button2.setOnClickListener { nextActivity() }
        } else if (connec.getNetworkInfo(0)!!.state == android.net.NetworkInfo.State.DISCONNECTED || connec.getNetworkInfo(1)!!.state == android.net.NetworkInfo.State.DISCONNECTED) {
            nextActivity()
        }
    }

    private fun update() {
        ApiClient.client?.create(ApiInterface::class.java!!)?.getupdate()?.enqueue(object : Callback<ResponseData> {
            override fun onResponse(call: Call<ResponseData>, response: Response<ResponseData>) {
                if (response.code() == 200) {
                    askForeUpdate(response.body()!!.success, response.body()!!.ver)
                    //                    askForeUpdate(1, "1.0");
                }
            }

            override fun onFailure(call: Call<ResponseData>, t: Throwable) {}
        })
    }

    fun nextActivity() {


        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
        finish()
    }

    fun askForeUpdate(upd: Int?, playstoreVersionName: String?) {
        var versionname: String
        try {
            versionname = packageManager.getPackageInfo(packageName, 0).versionName
        } catch (e: PackageManager.NameNotFoundException) {
            versionname = "1.0"
        }

        when (upd) {
            0 -> nextActivity()
            1 -> if (versionname != playstoreVersionName) {
                relativeLayout.visibility = View.VISIBLE
            } else {
                nextActivity()
            }
            2 -> if (versionname != playstoreVersionName) {
                relativeLayout.visibility = View.VISIBLE
                button2.visibility = View.GONE
            } else {
                nextActivity()
            }
        }
    }
}