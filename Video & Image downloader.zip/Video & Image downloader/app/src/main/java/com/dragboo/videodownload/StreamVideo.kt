package com.dragboo.videodownload

import android.app.ProgressDialog
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.MediaController
import android.widget.VideoView
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar

import com.unity3d.ads.UnityAds

class StreamVideo : AppCompatActivity() {
    internal var VideoURL: String? = null
    internal lateinit var pDialog: ProgressDialog
    internal lateinit var toolbar: Toolbar
    internal lateinit var videoview: VideoView

    internal inner class C04851 : MediaPlayer.OnPreparedListener {
        override fun onPrepared(mediaPlayer: MediaPlayer) {
            this@StreamVideo.pDialog.dismiss()
            this@StreamVideo.videoview.start()
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    override fun onCreate(bundle: Bundle?) {
        super.onCreate(bundle)
        setContentView(R.layout.video_view)


        toolbar = findViewById<View>(R.id.toolbar) as Toolbar
        setSupportActionBar(toolbar)
        supportActionBar!!.setDisplayShowTitleEnabled(false)
        VideoURL = intent.getStringExtra(TAG_VIDURL)
        this.videoview = findViewById<View>(R.id.streaming_video) as VideoView
        this.pDialog = ProgressDialog(this)
        this.pDialog.setTitle("Video Stream")
        this.pDialog.setMessage("Buffering...")
        this.pDialog.isIndeterminate = false
        this.pDialog.setCancelable(false)
        this.pDialog.show()
        try {
            val myuri = Uri.parse(VideoURL)
            this.videoview.setMediaController(MediaController(this))
            this.videoview.setVideoURI(myuri)
        } catch (bundle2: Exception) {
            Log.e("Error", bundle2.message)
        }

        this.videoview.requestFocus()
        this.videoview.setOnPreparedListener(C04851())
    }

    companion object {
        private val TAG_VIDURL = "video_url"
    }
}