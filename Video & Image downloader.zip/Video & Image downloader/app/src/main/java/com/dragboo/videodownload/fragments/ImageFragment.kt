package com.dragboo.videodownload.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.dragboo.videodownload.R
import com.dragboo.videodownload.adapters.RecyclerAdapter
import com.dragboo.videodownload.adapters.RecyclerInstances
import com.dragboo.videodownload.data.FilesData

class ImageFragment : Fragment() {
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val v = inflater.inflate(R.layout.st_video_image_fragment, container, false)
        if (FilesData.recentOrSaved == "recent") {
            RecyclerInstances.recentImageRecyclerview = v.findViewById(R.id.videoImageRecyclerView)
            RecyclerInstances.recentImageRecyclerview!!.setHasFixedSize(true)
            val mLayoutManager = LinearLayoutManager(context)
            RecyclerInstances.recentImageRecyclerview!!.layoutManager = mLayoutManager
            if (FilesData.whatsAppFilesImages.isEmpty()) {
                FilesData.scrapWhatsAppFiles()
            }
            RecyclerInstances.recentImageAdapter = RecyclerAdapter(FilesData.whatsAppFilesImages, requireContext(), 'i')
            RecyclerInstances.recentImageRecyclerview!!.adapter = RecyclerInstances.recentImageAdapter
        } else {
            RecyclerInstances.savedImageRecyclerview = v.findViewById(R.id.videoImageRecyclerView)
            RecyclerInstances.savedImageRecyclerview!!.setHasFixedSize(true)
            val mLayoutManager = LinearLayoutManager(context)
            RecyclerInstances.savedImageRecyclerview!!.layoutManager = mLayoutManager
            if (FilesData.savedFilesImages.isEmpty()) {
                FilesData.scrapSavedFiles()
            }
            RecyclerInstances.savedImageAdapter = RecyclerAdapter(FilesData.savedFilesImages, requireContext(), 'i')
            RecyclerInstances.savedImageRecyclerview!!.adapter = RecyclerInstances.savedImageAdapter
        }
        return v
    }
}