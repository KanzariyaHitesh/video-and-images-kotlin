package com.dragboo.videodownload

import android.annotation.SuppressLint
import android.app.ProgressDialog
import android.os.Bundle
import android.os.Handler
import android.view.View
import android.widget.MediaController
import android.widget.Toast
import android.widget.VideoView

import androidx.appcompat.app.AppCompatActivity

import com.dragboo.videodownload.data.FilesData_Instagram
import com.unity3d.ads.UnityAds

import java.io.File
import java.util.ArrayList

class VideoViewerActivity_Instagram : AppCompatActivity() {
    internal var position: Int = 0
    private var progressDialog: ProgressDialog? = null
    private var vv: VideoView? = null
    private var mc: MediaController? = null
    private var flag = false

    @SuppressLint("NewApi")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_video_viewer)

        progressDialog = ProgressDialog(this)
        progressDialog!!.setCancelable(true)
        progressDialog!!.setMessage("showing Ad...")
        progressDialog!!.show()


        videos = FilesData_Instagram.savedFilesVideos
        try {
            position = intent.extras!!.getInt("position")
        } catch (e: NullPointerException) {
            Toast.makeText(this, getString(R.string.imageviewer_error), Toast.LENGTH_SHORT).show()
        }

        vv = findViewById(R.id.videoView)
        vv!!.setVideoPath(videos!![position].path)
        mc = MediaController(this, false)
        vv!!.setMediaController(mc)
        vv!!.fitsSystemWindows = true
        mc!!.show(0)
        mc!!.visibility = View.VISIBLE
        mc!!.setAnchorView(vv)
        vv!!.pause()
        mc!!.setPrevNextListeners({
            // next button clicked
            if (videos!!.size - 1 == position) {
                position = 0
                vv!!.setVideoPath(videos!![position].path)
                vv!!.start()
            } else {
                vv!!.setVideoPath(videos!![++position].path)
                vv!!.start()
            }
        }, {
            if (position == 0) {
                position = videos!!.size - 1
                vv!!.setVideoPath(videos!![position].path)
                vv!!.start()
            } else {
                vv!!.setVideoPath(videos!![--position].path)
                vv!!.start()
            }
        })

        Handler().postDelayed({
            if (UnityAds.isReady("video")) {
                flag = true
                UnityAds.show(this@VideoViewerActivity_Instagram, "video")
                progressDialog!!.dismiss()
            } else {
                flag = true
                progressDialog!!.dismiss()
            }
        }, 10000)


    }

    override fun onResume() {
        super.onResume()
        if (flag) {
            if (vv != null) {
                vv!!.start()
            }
        }
    }

    companion object {
        private var videos: ArrayList<File>? = null
    }

}