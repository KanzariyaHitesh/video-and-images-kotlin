package com.dragboo.videodownload.filesoperations

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import com.dragboo.videodownload.R
import com.dragboo.videodownload.data.FilesData
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.nio.channels.FileChannel

object FileOperations {
    fun deleteAndRefreshFiles(file: File) {
        file.delete()
        FilesData.scrapSavedFiles()
    }

    @Throws(IOException::class)
    fun saveAndRefreshFiles(sourceFile: File) {
        val destFile = File(Environment.getExternalStorageDirectory().toString() + FilesData.savedFilesLocation, sourceFile.name)
        if (!destFile.parentFile!!.exists())
            destFile.parentFile!!.mkdirs()
        if (!destFile.exists()) {
            destFile.createNewFile()
        }
        var source: FileChannel? = null
        var destination: FileChannel? = null
        try {
            source = FileInputStream(sourceFile).channel
            destination = FileOutputStream(destFile).channel
            destination!!.transferFrom(source, 0, source!!.size())
        } finally {
            source?.close()
            destination?.close()
        }
        FilesData.scrapSavedFiles()
    }

    fun shareFile(file: File, c: Context, type: Char) {
        val shareIntent = Intent()
        shareIntent.action = Intent.ACTION_SEND
        val uri = Uri.parse(file.path)
        if (type == 'i') {
            shareIntent.type = "image/*"
            shareIntent.putExtra(Intent.EXTRA_STREAM, uri)
            c.startActivity(Intent.createChooser(shareIntent, c.getString(R.string.share_using)))
        } else {
            shareIntent.type = "video/*"
            shareIntent.putExtra(Intent.EXTRA_STREAM, uri)
            c.startActivity(Intent.createChooser(shareIntent, c.getString(R.string.share_using)))
        }
    }
}