package com.dragboo.videodownload

import android.app.ProgressDialog
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.util.Log
import android.view.MenuItem
import android.view.View
import android.widget.ImageView
import android.widget.RelativeLayout

import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentTransaction

import com.google.android.material.bottomnavigation.BottomNavigationView
import com.unity3d.ads.UnityAds

import java.io.File

class MainActivity : AppCompatActivity() {
    internal lateinit var instagram: ImageView
    internal lateinit var facebook: ImageView
    internal lateinit var whatapp: ImageView
    internal lateinit var toolbar: androidx.appcompat.widget.Toolbar
    internal lateinit var relativeLayout: RelativeLayout
    internal lateinit var relativeLayout_main: RelativeLayout
    internal lateinit var view: View
    //    public static InterstitialAd mInterstitialAd;
    internal lateinit var navigation: BottomNavigationView

    private var progressDialog: ProgressDialog? = null

    private val mOnNavigationItemSelectedListener = BottomNavigationView.OnNavigationItemSelectedListener { item ->
        val id = item.itemId
        if (id == R.id.navigation_instagram) {
            val fragmentManager = supportFragmentManager
            val fragmentTransaction = fragmentManager.beginTransaction()
            val fragment = InstagramFragment()
            fragmentTransaction.replace(R.id.fragment_container, fragment)
            fragmentTransaction.addToBackStack("tag")
            fragmentTransaction.commit()
            findViewById<View>(R.id.fragment_container).visibility = View.VISIBLE
            relativeLayout.visibility = View.INVISIBLE
            //                AdView.setVisibility(View.GONE);
        } else if (id == R.id.navigation_facebook) {
            val fragmentManager = supportFragmentManager
            val fragmentTransaction = fragmentManager.beginTransaction()
            val fragment = FacebookFragment()
            fragmentTransaction.replace(R.id.fragment_container, fragment)
            fragmentTransaction.addToBackStack("tag")
            fragmentTransaction.commit()
            findViewById<View>(R.id.fragment_container).visibility = View.VISIBLE
            relativeLayout.visibility = View.INVISIBLE
            //                AdView.setVisibility(View.GONE);
        } else if (id == R.id.navigation_whatapp) {
            relativeLayout_main.setBackgroundColor(resources.getColor(R.color.main_bg))
            val fragmentManager = supportFragmentManager
            val fragmentTransaction = fragmentManager.beginTransaction()
            val fragment = WhatappFragment()
            fragmentTransaction.replace(R.id.fragment_container, fragment)
            fragmentTransaction.addToBackStack("tag")
            fragmentTransaction.commit()
            findViewById<View>(R.id.fragment_container).visibility = View.VISIBLE
            relativeLayout.visibility = View.INVISIBLE
            //                AdView.setVisibility(View.GONE);
        } else if (id == R.id.navigation_download) {
            relativeLayout_main.setBackgroundColor(resources.getColor(R.color.main_bg))
            val fragmentManager = supportFragmentManager
            val fragmentTransaction = fragmentManager.beginTransaction()
            val fragment = DowmloadFragment()
            fragmentTransaction.replace(R.id.fragment_container, fragment)
            fragmentTransaction.addToBackStack("tag")
            fragmentTransaction.commit()
            findViewById<View>(R.id.fragment_container).visibility = View.VISIBLE
            relativeLayout.visibility = View.INVISIBLE
            //                AdView.setVisibility(View.GONE);
        } else if (id == android.R.id.home) {
            finish()
        }
        true
    }
    internal var firstClick: Long? = 1L
    internal var secondClick: Long? = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        relativeLayout = findViewById<View>(R.id.relativemain) as RelativeLayout
        relativeLayout_main = findViewById<View>(R.id.RelativvLayout_Main) as RelativeLayout
        //        share=(Button)findViewById(R.id.share);
        //        rate=(Button)findViewById(R.id.rate_us);


        progressDialog = ProgressDialog(this)
        progressDialog!!.setCancelable(true)
        progressDialog!!.setMessage("showing Ad...")
        progressDialog!!.show()

        if (ContextCompat.checkSelfPermission(applicationContext, "android.permission.READ_EXTERNAL_STORAGE") != 0 && ContextCompat.checkSelfPermission(applicationContext, "android.permission.WRITE_EXTERNAL_STORAGE") != 0) {
            ActivityCompat.requestPermissions(this, MainActivity.PERMISSIONS_STORAGE!!, 1)
        }
        val mediaStorageDir = File(Environment.getExternalStorageDirectory(), "Video and Image Download")
        //            File dir = new File(mediaStorageDir.getAbsolutePath());
        if (!mediaStorageDir.exists()) {
            mediaStorageDir.mkdirs()
            if (!mediaStorageDir.mkdirs()) {
                Log.d("directory_not_create", "failed to create directory")
            }
        }
        toolbar = findViewById<View>(R.id.toolbar) as Toolbar
        setSupportActionBar(toolbar)
        supportActionBar!!.setDisplayShowTitleEnabled(false)
        //            AdView = (com.google.android.gms.ads.AdView) findViewById(R.id.adView1);
        //            AdView.setVisibility(View.VISIBLE);
        //            AdView.loadAd(new AdRequest.Builder().build());
        instagram = findViewById<View>(R.id.instagram) as ImageView
        facebook = findViewById<View>(R.id.facebook) as ImageView
        whatapp = findViewById<View>(R.id.whatapp) as ImageView
        navigation = findViewById<View>(R.id.navigation) as BottomNavigationView
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener)
        findViewById<View>(R.id.fragment_container).visibility = View.INVISIBLE
        navigation.itemIconTintList = null
        //        navigation.setVisibility(View.GONE);
        instagram.setOnClickListener { view ->
            var view = view
            view = navigation.findViewById(R.id.navigation_instagram)
            view.performClick()
            val fragmentManager = supportFragmentManager
            val fragmentTransaction = fragmentManager.beginTransaction()
            val fragment = InstagramFragment()
            fragmentTransaction.replace(R.id.fragment_container, fragment)
            fragmentTransaction.addToBackStack("tag")
            fragmentTransaction.commit()
            navigation.visibility = View.VISIBLE
            findViewById<View>(R.id.fragment_container).visibility = View.VISIBLE
            relativeLayout.visibility = View.GONE
            //                    AdView.setVisibility(View.GONE);
        }
        facebook.setOnClickListener { view ->
            var view = view
            view = navigation.findViewById(R.id.navigation_facebook)
            view.performClick()
            val fragmentManager = supportFragmentManager
            val fragmentTransaction = fragmentManager.beginTransaction()
            val fragment = FacebookFragment()
            fragmentTransaction.replace(R.id.fragment_container, fragment)
            fragmentTransaction.addToBackStack("tag")
            fragmentTransaction.commit()
            navigation.visibility = View.VISIBLE
            findViewById<View>(R.id.fragment_container).visibility = View.VISIBLE
            relativeLayout.visibility = View.GONE
            //                    AdView.setVisibility(View.GONE);
        }
        whatapp.setOnClickListener { view ->
            var view = view
            view = navigation.findViewById(R.id.navigation_whatapp)
            view.performClick()
            relativeLayout_main.setBackgroundColor(resources.getColor(R.color.main_bg))
            val fragmentManager = supportFragmentManager
            val fragmentTransaction = fragmentManager.beginTransaction()
            val fragment = WhatappFragment()
            fragmentTransaction.replace(R.id.fragment_container, fragment)
            fragmentTransaction.addToBackStack("tag")
            fragmentTransaction.commit()
            navigation.visibility = View.VISIBLE
            findViewById<View>(R.id.fragment_container).visibility = View.VISIBLE
            relativeLayout.visibility = View.GONE
            //                    AdView.setVisibility(View.GONE);
        }
        //            share.setOnClickListener(new View.OnClickListener() {
        //                @Override
        //                public void onClick(View view) {
        //                    String url="URL: http://bit.ly/2Yb7Nhl";
        //                    Intent shareIntent = new Intent(Intent.ACTION_SEND);
        //                    shareIntent.setType("text/plain");
        //                    shareIntent.putExtra(Intent.EXTRA_TEXT,"You want to download instagram, facebook and whatsapp images, videos and story?\n" +
        //                            "Download Now:"+"\n"+ url);
        //                    startActivity(Intent.createChooser(shareIntent, "Share link using"));
        //                }
        //            });
        //            rate.setOnClickListener(new View.OnClickListener() {
        //                @Override
        //                public void onClick(View view) {
        //                    Uri uri = Uri.parse("market://details?id=" + getPackageName());
        //                    Intent goToMarket = new Intent(Intent.ACTION_VIEW, uri);
        //                    goToMarket.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY | Intent.FLAG_ACTIVITY_NEW_DOCUMENT | Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
        //                    try {
        //                        startActivity(goToMarket);
        //                    } catch (ActivityNotFoundException e) {
        //                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://play.google.com/store/apps/details?id=" + getPackageName())));
        //                    }
        //                }
        //            });
        val type = intent.getStringExtra("From")
        if (type != null) {
            if (type == "notifyFrag") {
                view = navigation.findViewById(R.id.navigation_download)
                view.performClick()
                relativeLayout_main.setBackgroundColor(resources.getColor(R.color.main_bg))
                val fragmentManager = supportFragmentManager
                val fragmentTransaction = fragmentManager.beginTransaction()
                val fragment = DowmloadFragment()
                fragmentTransaction.replace(R.id.fragment_container, fragment)
                fragmentTransaction.addToBackStack("tag")
                fragmentTransaction.commitAllowingStateLoss()
                findViewById<View>(R.id.fragment_container).visibility = View.VISIBLE
                relativeLayout.visibility = View.INVISIBLE
                //                    AdView.setVisibility(View.GONE);
                return
            }
        }

        Handler().postDelayed({
            if (UnityAds.isReady("video")) {
                UnityAds.show(this@MainActivity, "video")
                progressDialog!!.dismiss()
            } else {
                progressDialog!!.dismiss()
            }
        }, 10000)

    }

    override fun onBackPressed() {
        secondClick = System.currentTimeMillis()
        if ((secondClick!! - firstClick!!) / 1000 < 2) {
            finish()
        } else {
            firstClick = System.currentTimeMillis()
            relativeLayout.visibility = View.VISIBLE
            //            AdView.setVisibility(View.VISIBLE);
            findViewById<View>(R.id.fragment_container).visibility = View.INVISIBLE
        }
    }

    companion object {
        private var PERMISSIONS_STORAGE: Array<String>? = null

        //    private AdView AdView;
        init {
            PERMISSIONS_STORAGE = null
            PERMISSIONS_STORAGE = arrayOf("android.permission.WRITE_EXTERNAL_STORAGE", "android.permission.READ_EXTERNAL_STORAGE")
        }
    }
}