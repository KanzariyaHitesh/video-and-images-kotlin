package com.dragboo.videodownload.data

import android.os.Environment
import java.io.File
import java.util.ArrayList
import java.util.Arrays
import org.apache.commons.io.comparator.LastModifiedFileComparator.*

object FilesData {
    internal val WHATSAPP_STATUSES_LOCATION = "/WhatsApp/Media/.Statuses"
    val savedFilesLocation = "/Video and Image Download/WhatsAppStatusDownloader"
    val whatsAppFilesImages = ArrayList<File>()
    val whatsAppFilesVideos = ArrayList<File>()
    val savedFilesImages = ArrayList<File>()
    val savedFilesVideos = ArrayList<File>()
    var recentOrSaved: String? = null

    fun scrapWhatsAppFiles() {
        whatsAppFilesImages.clear()
        whatsAppFilesVideos.clear()
        val files: Array<File>?
        val parentDir = File(Environment.getExternalStorageDirectory().toString() + WHATSAPP_STATUSES_LOCATION)
        if (!parentDir.exists())
            parentDir.mkdirs()
        files = parentDir.listFiles()
        Arrays.sort(files!!, LASTMODIFIED_REVERSE)
        if (files != null) {
            for (file in files) {
                if (file.name.endsWith(".jpg")) {
                    if (!whatsAppFilesImages.contains(file))
                        whatsAppFilesImages.add(file)

                } else if (file.name.endsWith(".gif") || file.name.endsWith(".mp4")) {
                    if (!whatsAppFilesVideos.contains(file))
                        whatsAppFilesVideos.add(file)
                }
            }
        }
    }

    fun scrapSavedFiles() {
        savedFilesImages.clear()
        savedFilesVideos.clear()
        val files: Array<File>?
        val parentDir = File(Environment.getExternalStorageDirectory().toString() + savedFilesLocation)
        if (!parentDir.exists())
            parentDir.mkdirs()
        files = parentDir.listFiles()
        Arrays.sort(files!!, LASTMODIFIED_REVERSE)
        if (files != null) {
            for (file in files) {
                if (file.name.endsWith(".jpg")) {
                    if (!savedFilesImages.contains(file))
                        savedFilesImages.add(file)
                } else if (file.name.endsWith(".gif") || file.name.endsWith(".mp4")) {

                    if (!savedFilesVideos.contains(file))
                        savedFilesVideos.add(file)
                }
            }
        }
    }
}