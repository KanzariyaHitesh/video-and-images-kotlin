package com.dragboo.videodownload.adapters

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Build
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import android.widget.Toolbar
import androidx.annotation.RequiresApi
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.dragboo.videodownload.ImageViewerActivity
import com.dragboo.videodownload.MainActivity
import com.dragboo.videodownload.R
import com.dragboo.videodownload.VideoViewerActivity
import com.dragboo.videodownload.data.FilesData
import com.dragboo.videodownload.filesoperations.FileOperations
import java.io.File
import java.io.IOException
import java.util.ArrayList

class RecyclerAdapter
//    private InterstitialAd interstitialAd;
(myDataset: ArrayList<File>, private val mContext: Context, private val contentType: Char) : RecyclerView.Adapter<RecyclerAdapter.ViewHolder>() {
    private var mDataset: ArrayList<File>? = ArrayList()
    var v: CardView? = null

    init {
        mDataset = myDataset
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        if (mDataset != null && !mDataset!!.isEmpty()) {
            if (contentType == 'i') {
                v = LayoutInflater.from(parent.context).inflate(R.layout.st_recyclerview_image_item, parent, false) as CardView
            } else {
                v = LayoutInflater.from(parent.context).inflate(R.layout.st_recyclerview_video_item, parent, false) as CardView
            }
        } else {
            v = LayoutInflater.from(parent.context).inflate(R.layout.st_empty_warning, parent, false) as CardView
            if (contentType == 'i') {
                val textView = v!!.findViewById<View>(R.id.textView) as TextView
                textView.text = "No image download yet"
            } else {
                val textView = v!!.findViewById<View>(R.id.textView) as TextView
                textView.text = "No video download yet"
            }
        }
        return ViewHolder(v!!)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        if (mDataset != null) {
            if (!mDataset!!.isEmpty()) {
                if (contentType == 'i') {
                    Glide.with(mContext)
                            .load(mDataset!![position].path)
                            .override(600, 400)
                            .centerCrop()
                            .into(holder.mImageView!!)

                    holder.mImageView.setOnClickListener {
                        val i = Intent(mContext, ImageViewerActivity::class.java)
                        i.putExtra("path", mDataset!![position].path)
                        mContext.startActivity(i)
                    }
                } else {
                    Glide.with(mContext)
                            .load(mDataset!![position].path)
                            .override(600, 400)
                            .centerCrop()
                            .into(holder.mImageView!!)

                    holder.mImageView.setOnClickListener {
                        val i = Intent(mContext, VideoViewerActivity::class.java)
                        i.putExtra("position", position)
                        mContext.startActivity(i)
                    }
                }
                holder.shareButton!!.setOnClickListener { FileOperations.shareFile(mDataset!![position], mContext, contentType) }

                if (FilesData.recentOrSaved != "recent") {
                    holder.saveOrDelete!!.text = mContext.getString(R.string.delete)

                }
                holder.saveOrDelete!!.setOnClickListener {
                    if (FilesData.recentOrSaved == "recent") {
                        try {
                            //                                showInterstitial();
                            FileOperations.saveAndRefreshFiles(mDataset!![position])
                            Toast.makeText(mContext, mContext.getString(R.string.story_saved), Toast.LENGTH_SHORT).show()
                        } catch (e: IOException) {
                            Toast.makeText(mContext, mContext.getString(R.string.saving_failed), Toast.LENGTH_SHORT).show()
                        }

                    } else {
                        if (contentType == 'i') {
                            FileOperations.deleteAndRefreshFiles(FilesData.savedFilesImages[position])
                            mDataset = FilesData.savedFilesImages
                            RecyclerInstances.savedImageAdapter!!.notifyDataSetChanged()
                            RecyclerInstances.savedImageRecyclerview!!.adapter = RecyclerInstances.savedImageAdapter
                        } else {
                            FileOperations.deleteAndRefreshFiles(FilesData.savedFilesVideos[position])
                            mDataset = FilesData.savedFilesVideos
                            RecyclerInstances.savedVideoAdapter!!.notifyDataSetChanged()
                            RecyclerInstances.savedVideoRecyclerview!!.adapter = RecyclerInstances.savedVideoAdapter
                        }
                    }
                }
            }
        }
    }

    override fun getItemCount(): Int {
        return if (mDataset != null) {
            if (mDataset!!.isEmpty()) {
                1
            } else {
                mDataset!!.size
            }
        } else {
            0
        }
    }

    inner class ViewHolder(v: CardView) : RecyclerView.ViewHolder(v) {
        val mImageView: ImageView? = v.findViewById(R.id.vvr)
        val shareButton: Button? = v.findViewById(R.id.sharefilebutton)
        val saveOrDelete: Button? = v.findViewById(R.id.saveORdelete)
    }

    //    public void showInterstitial() {
    //        ((Activity)mContext).runOnUiThread(new Runnable() {
    //            public void run() {
    //                if (MainActivity.mInterstitialAd == null || !MainActivity.mInterstitialAd.isLoaded()) {
    //                    interstitialAd = new InterstitialAd(mContext);
    //                    interstitialAd.setAdUnitId(mContext.getResources().getString(R.string.ad_intert_id));
    //                    interstitialAd.loadAd(new AdRequest.Builder().build());
    //                    interstitialAd.setAdListener(new LoadAds());
    //                    return;
    //                } else {
    //                    //Log.d(TAG, "Interstitial ad is not loaded yet");
    //                }
    //                MainActivity.mInterstitialAd.show();
    //            }
    //        });
    //    }

    //    class LoadAds extends AdListener {
    //        LoadAds() { }
    //        public void onAdLoaded() {
    //            if (interstitialAd != null && interstitialAd.isLoaded()) {
    //                interstitialAd.show();
    //            }
    //        }
    //        public void onAdFailedToLoad(int errorCode) { }
    //        public void onAdOpened() { }
    //        public void onAdLeftApplication() { }
    //        public void onAdClosed() { }
    //    }
}