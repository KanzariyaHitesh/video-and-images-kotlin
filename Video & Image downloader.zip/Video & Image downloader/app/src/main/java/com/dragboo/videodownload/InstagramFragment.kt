package com.dragboo.videodownload

import android.annotation.SuppressLint
import android.app.DownloadManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.res.AssetManager
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.MimeTypeMap
import android.webkit.URLUtil
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ProgressBar
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.android.volley.Response
import com.android.volley.VolleyError
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import java.io.IOException
import java.io.InputStream

class InstagramFragment : Fragment() {
//    private var view: View? = null
private var root: View? = null
    internal lateinit var webView: WebView
    private var PageFinishText = ""
    internal var StoreReadFile = ""
    //    private InterstitialAd interstitialAd;
    private var prgrsBar: ProgressBar? = null
    internal var id: Long = 0
    internal var fileExtensionFromUrl: String? = null
    internal lateinit var pendingIntent: PendingIntent
    internal var onDownloadComplete: BroadcastReceiver? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    @SuppressLint("NewApi")
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
//        if (view == null) {
        root= inflater.inflate(R.layout.instagram_fragmentview, container, false)
            prgrsBar = root!!.findViewById<View>(R.id.load) as ProgressBar
            prgrsBar!!.visibility = View.VISIBLE
            webView = root!!.findViewById<View>(R.id.webView) as WebView
            webView.settings.loadWithOverviewMode = true
            webView.settings.useWideViewPort = true
            webView.settings.builtInZoomControls = true
            webView.settings.domStorageEnabled = true
            webView.settings.pluginState = WebSettings.PluginState.ON
            GetRequestQueue()
            try {
                this.StoreReadFile = ReadTextFile_AddButton().toString()
            } catch (e: IOException) {
                e.printStackTrace()
            }

            WebViewSettings()
            MyWebView()

//        }
        return root
    }

    private fun MyWebView() {
        val webView = this.webView
        webView.setBackgroundColor(resources.getColor(R.color.White))
        val stringBuilder = StringBuilder()
        stringBuilder.append("https://www.instagram.com/")
        webView.loadUrl(stringBuilder.toString())
    }

    internal inner class ClientWebView(val instagramFragment:/* synthetic */ InstagramFragment) : WebViewClient() {
        override fun onLoadResource(webView: WebView, str: String) {
            try {
                val stringBuilder = StringBuilder()
                stringBuilder.append("javascript:(function() { ")
                stringBuilder.append(this.instagramFragment.StoreReadFile)
                stringBuilder.append("  })()")
                webView.loadUrl(stringBuilder.toString())
            } catch (e: Exception) {
                Log.d("myjs", e.message)
                e.printStackTrace()
            }

            super.onLoadResource(webView, str)
        }

        override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
            super.onPageStarted(view, url, favicon)
        }

        override fun onPageFinished(webView: WebView, str: String) {
            prgrsBar!!.visibility = View.GONE
            this.instagramFragment.PageFinishText = str
            super.onPageFinished(webView, str)
            val stringBuilder = StringBuilder()
            stringBuilder.append("javascript:(function() {")
            stringBuilder.append(this.instagramFragment.StoreReadFile)
            stringBuilder.append("  })()")
            webView.loadUrl(stringBuilder.toString())
        }

        @SuppressLint("NewApi")
        override fun shouldOverrideUrlLoading(webView: WebView, str: String): Boolean {
            var str = str
            fileExtensionFromUrl = MimeTypeMap.getFileExtensionFromUrl(str)
            if (fileExtensionFromUrl != null) {
                if (MimeTypeMap.getSingleton().getMimeTypeFromExtension(fileExtensionFromUrl) != null) {
                    val downloadManager = activity!!.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                    val request = DownloadManager.Request(Uri.parse(str))
                    str = URLUtil.guessFileName(str, null, MimeTypeMap.getFileExtensionFromUrl(str))
                    request.setDescription(this.instagramFragment.getString(R.string.val_download))
                    val intent = Intent(activity, MainActivity::class.java)
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    intent.putExtra("From", "notifyFrag")
                    pendingIntent = PendingIntent.getActivity(context, 0, intent, 0)
                    activity
                    val mgr = activity!!.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                    id = mgr.enqueue(request)
                    onDownloadComplete = object : BroadcastReceiver() {
                        override fun onReceive(context: Context, intent: Intent) {
                            //Fetching the download id received with the broadcast
                            val ids = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1)
                            //Checking if the received broadcast is for our enqueued download by matching download id
                            if (id == ids) {
                                //                        Toast.makeText(getContext(), "Download Completed", Toast.LENGTH_SHORT).show();
                                if (fileExtensionFromUrl == "jpg") {
                                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                                        count_image = 1 + count_image
                                        val mNotificationManager = activity!!.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                                        val mBuilder = NotificationCompat.Builder(getContext())
                                                .setSmallIcon(R.drawable.app_icon)
                                                .setContentTitle("Image has been downloaded")
                                                .setContentText("Instagram")
                                                .setAutoCancel(true)
                                                .setNumber(count_image)
                                                .setDefaults(0)
                                        mBuilder.setContentIntent(pendingIntent)
                                                .build()

                                        val importance = NotificationManager.IMPORTANCE_HIGH
                                        val notificationChannel = NotificationChannel(NOTIFICATION_CHANNEL_ID, "NOTIFICATION_CHANNEL_NAME", importance)
                                        notificationChannel.enableLights(true)
                                        notificationChannel.lightColor = Color.RED
                                        notificationChannel.enableVibration(true)
                                        notificationChannel.vibrationPattern = longArrayOf(100, 200, 300, 400, 500, 400, 300, 200, 400)
                                        assert(mNotificationManager != null)
                                        mBuilder.setChannelId(NOTIFICATION_CHANNEL_ID)
                                        mNotificationManager.createNotificationChannel(notificationChannel)
                                        assert(mNotificationManager != null)
                                        mNotificationManager.notify(0 /* Request Code */, mBuilder.build())
                                    } else {
                                        count_image = 1 + count_image
                                        val mBuilder = NotificationCompat.Builder(getContext())
                                                .setSmallIcon(R.drawable.app_icon)
                                                .setContentTitle("Image has been downloaded")
                                                .setContentText("Instagram")
                                                .setAutoCancel(true)
                                                .setNumber(count_image)
                                                .setDefaults(0)
                                        mBuilder.setContentIntent(pendingIntent)
                                        val notificationManager = activity!!.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                                        notificationManager.notify(0, mBuilder.build())
                                    }
                                } else {
                                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                                        count_vedio = 1 + count_vedio
                                        val mNotificationManager = activity!!.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                                        val mBuilder = NotificationCompat.Builder(getContext())
                                                .setSmallIcon(R.drawable.app_icon)
                                                .setContentTitle("Video has been downloaded")
                                                .setContentText("Instagram")
                                                .setAutoCancel(true)
                                                .setNumber(count_image)
                                                .setDefaults(0)
                                        mBuilder.setContentIntent(pendingIntent)
                                                .build()

                                        val importance = NotificationManager.IMPORTANCE_HIGH
                                        val notificationChannel = NotificationChannel(NOTIFICATION_CHANNEL_ID, "NOTIFICATION_CHANNEL_NAME", importance)
                                        notificationChannel.enableLights(true)
                                        notificationChannel.lightColor = Color.RED
                                        notificationChannel.enableVibration(true)
                                        notificationChannel.vibrationPattern = longArrayOf(100, 200, 300, 400, 500, 400, 300, 200, 400)
                                        assert(mNotificationManager != null)
                                        mBuilder.setChannelId(NOTIFICATION_CHANNEL_ID)
                                        mNotificationManager.createNotificationChannel(notificationChannel)
                                        assert(mNotificationManager != null)
                                        mNotificationManager.notify(0 /* Request Code */, mBuilder.build())
                                    } else {
                                        count_vedio = 1 + count_vedio
                                        val mBuilder = NotificationCompat.Builder(getContext())
                                                .setSmallIcon(R.drawable.app_icon)
                                                .setContentTitle("Video has been downloaded")
                                                .setContentText("Instagram")
                                                .setAutoCancel(true)
                                                .setNumber(count_vedio)
                                                .setDefaults(0)
                                        mBuilder.setContentIntent(pendingIntent)
                                        val notificationManager = activity!!.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                                        notificationManager.notify(0, mBuilder.build())
                                    }
                                }
                            }
                        }
                    }
                    activity!!.registerReceiver(onDownloadComplete, IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE))
                    request.setDestinationInExternalPublicDir("Video and Image Download/Instagram Download", str)
                    downloadManager?.enqueue(request)
                    return true
                }
            }
            return false
        }
    }

    @SuppressLint("NewApi")
    fun Download_Piture_Video(str: String) {
        var str = str
        fileExtensionFromUrl = MimeTypeMap.getFileExtensionFromUrl(str)
        if (fileExtensionFromUrl != null && MimeTypeMap.getSingleton().getMimeTypeFromExtension(fileExtensionFromUrl) != null) {
            val downloadManager = activity!!.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            val request = DownloadManager.Request(Uri.parse(str))
            str = URLUtil.guessFileName(str, null, MimeTypeMap.getFileExtensionFromUrl(str))
            request.setDescription(getString(R.string.val_download))
            val intent = Intent(activity, MainActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            intent.putExtra("From", "notifyFrag")
            pendingIntent = PendingIntent.getActivity(context, 0, intent, 0)
            activity
            val mgr = activity!!.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            id = mgr.enqueue(request)
            onDownloadComplete = object : BroadcastReceiver() {
                override fun onReceive(context: Context, intent: Intent) {
                    //Fetching the download id received with the broadcast
                    val ids = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1)
                    //Checking if the received broadcast is for our enqueued download by matching download id
                    if (id == ids) {
                        //                        Toast.makeText(getContext(), "Download Completed", Toast.LENGTH_SHORT).show();
                        if (fileExtensionFromUrl == "jpg") {
                            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                                count_image = 1 + count_image
                                val mNotificationManager = activity!!.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                                val mBuilder = NotificationCompat.Builder(getContext())
                                        .setSmallIcon(R.drawable.app_icon)
                                        .setContentTitle("Image has been downloaded")
                                        .setContentText("Instagram")
                                        .setAutoCancel(true)
                                        .setNumber(count_image)
                                        .setDefaults(0)
                                mBuilder.setContentIntent(pendingIntent)
                                        .build()

                                val importance = NotificationManager.IMPORTANCE_HIGH
                                val notificationChannel = NotificationChannel(NOTIFICATION_CHANNEL_ID, "NOTIFICATION_CHANNEL_NAME", importance)
                                notificationChannel.enableLights(true)
                                notificationChannel.lightColor = Color.RED
                                notificationChannel.enableVibration(true)
                                notificationChannel.vibrationPattern = longArrayOf(100, 200, 300, 400, 500, 400, 300, 200, 400)
                                assert(mNotificationManager != null)
                                mBuilder.setChannelId(NOTIFICATION_CHANNEL_ID)
                                mNotificationManager.createNotificationChannel(notificationChannel)
                                assert(mNotificationManager != null)
                                mNotificationManager.notify(0 /* Request Code */, mBuilder.build())
                            } else {
                                count_image = 1 + count_image
                                val mBuilder = NotificationCompat.Builder(getContext())
                                        .setSmallIcon(R.drawable.app_icon)
                                        .setContentTitle("Image has been downloaded")
                                        .setContentText("Instagram")
                                        .setAutoCancel(true)
                                        .setNumber(count_image)
                                        .setDefaults(0)
                                mBuilder.setContentIntent(pendingIntent)
                                val notificationManager = activity!!.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                                notificationManager.notify(0, mBuilder.build())
                            }
                        } else {
                            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                                count_vedio = 1 + count_vedio
                                val mNotificationManager = activity!!.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                                val mBuilder = NotificationCompat.Builder(getContext())
                                        .setSmallIcon(R.drawable.app_icon)
                                        .setContentTitle("Video has been downloaded")
                                        .setContentText("Instagram")
                                        .setAutoCancel(true)
                                        .setNumber(count_image)
                                        .setDefaults(0)
                                mBuilder.setContentIntent(pendingIntent)
                                        .build()

                                val importance = NotificationManager.IMPORTANCE_HIGH
                                val notificationChannel = NotificationChannel(NOTIFICATION_CHANNEL_ID, "NOTIFICATION_CHANNEL_NAME", importance)
                                notificationChannel.enableLights(true)
                                notificationChannel.lightColor = Color.RED
                                notificationChannel.enableVibration(true)
                                notificationChannel.vibrationPattern = longArrayOf(100, 200, 300, 400, 500, 400, 300, 200, 400)
                                assert(mNotificationManager != null)
                                mBuilder.setChannelId(NOTIFICATION_CHANNEL_ID)
                                mNotificationManager.createNotificationChannel(notificationChannel)
                                assert(mNotificationManager != null)
                                mNotificationManager.notify(0 /* Request Code */, mBuilder.build())
                            } else {
                                count_vedio = 1 + count_vedio
                                val mBuilder = NotificationCompat.Builder(getContext())
                                        .setSmallIcon(R.drawable.app_icon)
                                        .setContentTitle("Video has been downloaded")
                                        .setContentText("Instagram")
                                        .setAutoCancel(true)
                                        .setNumber(count_vedio)
                                        .setDefaults(0)
                                mBuilder.setContentIntent(pendingIntent)
                                val notificationManager = activity!!.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                                notificationManager.notify(0, mBuilder.build())
                            }
                        }
                    }
                }
            }
            activity!!.registerReceiver(onDownloadComplete, IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE))
            request.setDestinationInExternalPublicDir("Video and Image Download/Instagram Download", str)
            downloadManager?.enqueue(request)
        }
    }

    fun GetRequestQueue() {
        val str = "https://pllio.com:8080/ares"
        Log.d("object mediation", str)
        Volley.newRequestQueue(context!!).add(StringRequest(0, str, FragmentResponce(this@InstagramFragment), InternetResponce(this@InstagramFragment)))
    }

    internal inner class InternetResponce(val f3746a:/* synthetic */ InstagramFragment) : Response.ErrorListener {
        override fun onErrorResponse(volleyError: VolleyError) {
            volleyError.printStackTrace()
            Log.d("NO INTERNET 2", "NO INTERNET 2")
        }
    }

    internal inner class FragmentResponce(val instagramFragment:/* synthetic */ InstagramFragment) : Response.Listener<String> {
        fun m5028a(str: String) {}

        override fun onResponse(response: String) {}
    }

    inner class FragmentContextResponce internal constructor(internal /* synthetic */ val instagramFragment: InstagramFragment, internal var context: Context) {

        @RequiresApi(api = Build.VERSION_CODES.KITKAT)
        @JavascriptInterface
        fun showToast(str: String) {
            Toast.makeText(this.context, "Downloading...", Toast.LENGTH_LONG).show()
            if (ContextCompat.checkSelfPermission(getContext()!!, "android.permission.READ_EXTERNAL_STORAGE") != 0) {
                ActivityCompat.requestPermissions(activity!!, InstagramFragment.PERMISSIONS_STORAGE!!, 1)
            }
            //            showInterstitial();
            this.instagramFragment.Download_Piture_Video(str)
        }
    }

    @SuppressLint("NewApi")
    private fun WebViewSettings() {
        this.webView.setInitialScale(1)
        this.webView.addJavascriptInterface(FragmentContextResponce(this@InstagramFragment, requireContext()), "Android")
        this.webView.settings.loadWithOverviewMode = true
        this.webView.settings.useWideViewPort = true
        this.webView.settings.javaScriptEnabled = true
        this.webView.settings.allowFileAccess = true
        this.webView.settings.savePassword = false
        this.webView.settings.allowContentAccess = true
        this.webView.isScrollbarFadingEnabled = true
        this.webView.webViewClient = ClientWebView(this)
    }

    @Throws(IOException::class)
    fun ReadTextFile_AddButton(): String {
        val assetManager = activity!!.assets
        val input: InputStream
        var text = ""
        try {
            input = assetManager.open("file.txt")
            val size = input.available()
            val buffer = ByteArray(size)
            input.read(buffer)
            input.close()
            // byte buffer into a string
            text = String(buffer)
        } catch (e: IOException) {
            // TODO Auto-generated catch block
            e.printStackTrace()
        }

        //        Log.v("TAG", "Text File: " + text);
        return text
    }
    //    public void showInterstitial() {
    //        getActivity().runOnUiThread(new Runnable() {
    //            public void run() {
    //                if (MainActivity.mInterstitialAd == null || !MainActivity.mInterstitialAd.isLoaded()) {
    //                    interstitialAd = new InterstitialAd(getContext());
    //                    interstitialAd.setAdUnitId(getString(R.string.ad_intert_id));
    //                    interstitialAd.loadAd(new AdRequest.Builder().build());
    //                    interstitialAd.setAdListener(new LoadAds());
    //                    return;
    //                }
    //                else {
    //                    //Log.d(TAG, "Interstitial ad is not loaded yet");
    //                }
    //                MainActivity.mInterstitialAd.show();
    //            }
    //        });
    //    }
    //    private class LoadAds extends AdListener {
    //        LoadAds() { }
    //        public void onAdLoaded() {
    //
    //            if (interstitialAd != null && interstitialAd.isLoaded()) {
    //                interstitialAd.show();
    //            }
    //        }
    //        public void onAdFailedToLoad(int errorCode) { }
    //        public void onAdOpened() { }
    //        public void onAdLeftApplication() { }
    //        public void onAdClosed() { }
    //    }

    override fun onDestroy() {
        try {
            if (onDownloadComplete != null)
                activity!!.unregisterReceiver(onDownloadComplete)
        } catch (e: Exception) {
        }

        super.onDestroy()
    }

    companion object {
        private var PERMISSIONS_STORAGE: Array<String>? = null
        private val NOTIFICATION_CHANNEL_ID = "notification_channel_id"
        internal var count_image: Int = 0
        internal var count_vedio = 0

        init {
            PERMISSIONS_STORAGE = null
            PERMISSIONS_STORAGE = arrayOf("android.permission.READ_EXTERNAL_STORAGE", "android.permission.READ_EXTERNAL_STORAGE")
        }
    }
}