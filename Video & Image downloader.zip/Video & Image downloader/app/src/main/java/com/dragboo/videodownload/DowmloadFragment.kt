package com.dragboo.videodownload

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentStatePagerAdapter
import androidx.viewpager.widget.ViewPager
import com.google.android.material.tabs.TabLayout
import com.dragboo.videodownload.data.FilesData_Facebook
import java.util.ArrayList

class DowmloadFragment : Fragment() {
//    private var view: View? = null
private var root: View? = null
    internal lateinit var tabLayout: TabLayout
    private val icons = intArrayOf(R.drawable.instagram, R.drawable.ic_facebook, R.drawable.ic_whatapp)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
//        if (view == null) {
        root= inflater.inflate(R.layout.activity_history, container, false)
            requestStoragePermission()
            childFragmentManager
            if (ContextCompat.checkSelfPermission(context!!, "android.permission.READ_EXTERNAL_STORAGE") != 0) {
                val intent = Intent(activity, MainActivity::class.java)
                startActivity(intent)
                ActivityCompat.requestPermissions(activity!!, DowmloadFragment.PERMISSIONS_STORAGE!!, 1)
            }
            requestStoragePermission()
            val mSectionsPagerAdapter = SectionsPagerAdapter(activity!!.supportFragmentManager)
            tabLayout = root!!.findViewById(R.id.tabs)
            tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
                override fun onTabSelected(tab: TabLayout.Tab) {
                    val position = tab.position
                    if (position == 0) {

                        tabLayout.setSelectedTabIndicatorColor(Color.parseColor("#F5242A"))
                    } else if (position == 1) {
                        tabLayout.setSelectedTabIndicatorColor(Color.parseColor("#3560AE"))
                    } else if (position == 2) {
                        tabLayout.setSelectedTabIndicatorColor(Color.parseColor("#2AB200"))
                    }
                }

                override fun onTabUnselected(tab: TabLayout.Tab) {}

                override fun onTabReselected(tab: TabLayout.Tab) {}
            })
            val viewPager = root!!.findViewById<ViewPager>(R.id.viewpager1)
            viewPager.adapter = mSectionsPagerAdapter
            viewPager.addOnPageChangeListener(TabLayout.TabLayoutOnPageChangeListener(tabLayout))
            tabLayout.addOnTabSelectedListener(TabLayout.ViewPagerOnTabSelectedListener(viewPager))
            for (i in 0 until tabLayout.tabCount) {
                tabLayout.getTabAt(i)!!.setIcon(icons[i])
            }
//        }
        return root
    }

    inner class SectionsPagerAdapter//        public SectionsPagerAdapter(FragmentManager fm) {
    //            super(fm);
    //            fragments.clear();
    //            fragments.add(new InstagramHistoryFragment());
    //            fragmentNames.add(getString(R.string.tab_historyinsta));
    //            fragments.add(new FacebookHistoryFragment());
    //            fragmentNames.add(getString(R.string.tab_historyfb));
    //            fragments.add(new WhatsappHistoryFragment());
    //            fragmentNames.add(getString(R.string.tab_historywp));
    //
    //        }
    (fm: FragmentManager) : FragmentStatePagerAdapter(fm) {
        private val fragments = ArrayList<Fragment>()
        private val fragmentNames = ArrayList<String>()

        init {
            fragments.clear()
            fragments.add(InstagramHistoryFragment())
            //            fragmentNames.add(getString(R.string.tab_historyinsta));
            //            tabLayout.getTabAt(1).setIcon(icons[1]);
            fragments.add(FacebookHistoryFragment())
            //            fragmentNames.add(getString(R.string.tab_historyfb));
            fragments.add(WhatsappHistoryFragment())
            //            fragmentNames.add(getString(R.string.tab_historywp));

        }

        override fun getItem(position: Int): Fragment {
            return fragments[position]
        }

        override fun getCount(): Int {
            return 3
        }

        override fun getPageTitle(position: Int): CharSequence? {
            return fragmentNames[position]
        }
    }

    private fun requestStoragePermission() {
        if (Build.VERSION.SDK_INT >= 23) {
            val permissions = arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
            if (ContextCompat.checkSelfPermission(context!!,
                            Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(activity!!, permissions, 123)
            } else {
                goToSavedStoriesTab()
            }
        } else {
            goToSavedStoriesTab()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions!!, grantResults)
        if (requestCode == 123) {
            if (grantResults.size != 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                goToSavedStoriesTab()
            }
        } else {
            Toast.makeText(context, getString(R.string.if_not_permitted), Toast.LENGTH_SHORT).show()
        }
    }

    private fun goToSavedStoriesTab() {
        FilesData_Facebook.scrapSavedFiles()
    }

    companion object {
        private var PERMISSIONS_STORAGE: Array<String>? = null
        init {
            PERMISSIONS_STORAGE = null
            PERMISSIONS_STORAGE = arrayOf("android.permission.READ_EXTERNAL_STORAGE", "android.permission.READ_EXTERNAL_STORAGE")
        }
    }
}