package com.dragboo.videodownload.filesoperations

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.dragboo.videodownload.R
import com.dragboo.videodownload.data.FilesData_Instagram
import java.io.File

object FileOperation_Instagram {
    fun deleteAndRefreshFiles(file: File) {
        file.delete()
        FilesData_Instagram.scrapSavedFiles()
    }

    fun shareFile(file: File, c: Context, type: Char) {
        val shareIntent = Intent()
        shareIntent.action = Intent.ACTION_SEND
        val uri = Uri.parse(file.path)
        if (type == 'i') {
            shareIntent.type = "image/*"
            shareIntent.putExtra(Intent.EXTRA_STREAM, uri)
            c.startActivity(Intent.createChooser(shareIntent, c.getString(R.string.share_using)))
        } else {
            shareIntent.type = "video/*"
            shareIntent.putExtra(Intent.EXTRA_STREAM, uri)
            c.startActivity(Intent.createChooser(shareIntent, c.getString(R.string.share_using)))
        }
    }
}