package com.dragboo.videodownload.update

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class ResponseData {
    @SerializedName("success")
    @Expose
    var success: Int? = null
    @SerializedName("ver")
    @Expose
    var ver: String? = null
}
