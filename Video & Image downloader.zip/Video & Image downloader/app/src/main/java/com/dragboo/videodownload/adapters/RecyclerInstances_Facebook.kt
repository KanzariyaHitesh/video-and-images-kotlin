package com.dragboo.videodownload.adapters

import androidx.recyclerview.widget.RecyclerView

object RecyclerInstances_Facebook {
    var savedVideoAdapter: RecyclerView.Adapter<*>? = null
    var savedVideoRecyclerview: RecyclerView? = null
}