package com.dragboo.videodownload.adapters

import androidx.recyclerview.widget.RecyclerView

object RecyclerInstances {
    var savedImageAdapter: RecyclerView.Adapter<*>? = null
    var savedVideoAdapter: RecyclerView.Adapter<*>? = null
    var recentImageAdapter: RecyclerView.Adapter<*>? = null
    var recentVideoAdapter: RecyclerView.Adapter<*>? = null
    var recentImageRecyclerview: RecyclerView? = null
    var recentVideoRecyclerview: RecyclerView? = null
    var savedImageRecyclerview: RecyclerView? = null
    var savedVideoRecyclerview: RecyclerView? = null
}