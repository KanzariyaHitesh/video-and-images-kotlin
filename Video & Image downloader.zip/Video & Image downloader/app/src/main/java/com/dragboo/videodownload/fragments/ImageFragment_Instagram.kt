package com.dragboo.videodownload.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.dragboo.videodownload.R
import com.dragboo.videodownload.adapters.RecyclerAdapter_Instagram
import com.dragboo.videodownload.adapters.RecyclerInstances_Instagram
import com.dragboo.videodownload.data.FilesData_Instagram

class ImageFragment_Instagram : Fragment() {
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val v = inflater.inflate(R.layout.st_video_image_fragment, container, false)
        RecyclerInstances_Instagram.savedImageRecyclerview = v.findViewById(R.id.videoImageRecyclerView)
        RecyclerInstances_Instagram.savedImageRecyclerview!!.setHasFixedSize(true)
        val mLayoutManager = LinearLayoutManager(context)
        RecyclerInstances_Instagram.savedImageRecyclerview!!.layoutManager = mLayoutManager
        if (FilesData_Instagram.savedFilesImages.isEmpty()) {
            FilesData_Instagram.scrapSavedFiles()
        }
        RecyclerInstances_Instagram.savedImageAdapter = RecyclerAdapter_Instagram(FilesData_Instagram.savedFilesImages, requireContext(), 'i')
        RecyclerInstances_Instagram.savedImageRecyclerview!!.adapter = RecyclerInstances_Instagram.savedImageAdapter
        return v
    }
}