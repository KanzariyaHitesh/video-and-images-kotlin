package com.dragboo.videodownload.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.dragboo.videodownload.R
import com.dragboo.videodownload.adapters.RecyclerAdapter
import com.dragboo.videodownload.adapters.RecyclerInstances
import com.dragboo.videodownload.data.FilesData

class VideoFragment : Fragment() {
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val v = inflater.inflate(R.layout.st_video_image_fragment, container, false)
        if (FilesData.recentOrSaved == "recent") {
            RecyclerInstances.recentVideoRecyclerview = v.findViewById(R.id.videoImageRecyclerView)
            RecyclerInstances.recentVideoRecyclerview!!.setHasFixedSize(true)
            val mLayoutManager = LinearLayoutManager(context)
            RecyclerInstances.recentVideoRecyclerview!!.layoutManager = mLayoutManager
            if (FilesData.whatsAppFilesVideos.isEmpty()) {
                FilesData.scrapWhatsAppFiles()
            }
            RecyclerInstances.recentVideoAdapter = RecyclerAdapter(FilesData.whatsAppFilesVideos, requireContext(), 'v')
            RecyclerInstances.recentVideoRecyclerview!!.adapter = RecyclerInstances.recentVideoAdapter
        } else {
            RecyclerInstances.savedVideoRecyclerview = v.findViewById(R.id.videoImageRecyclerView)
            RecyclerInstances.savedVideoRecyclerview!!.setHasFixedSize(true)
            val mLayoutManager = LinearLayoutManager(context)
            RecyclerInstances.savedVideoRecyclerview!!.layoutManager = mLayoutManager
            if (FilesData.savedFilesVideos.isEmpty()) {
                FilesData.scrapSavedFiles()
            }
            RecyclerInstances.savedVideoAdapter = RecyclerAdapter(FilesData.savedFilesVideos, requireContext(), 'v')
            RecyclerInstances.savedVideoRecyclerview!!.adapter = RecyclerInstances.savedVideoAdapter
        }
        return v
    }
}