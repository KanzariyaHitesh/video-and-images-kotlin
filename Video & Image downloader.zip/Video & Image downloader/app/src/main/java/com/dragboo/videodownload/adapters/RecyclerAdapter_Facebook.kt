package com.dragboo.videodownload.adapters

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.dragboo.videodownload.R
import com.dragboo.videodownload.VideoViewerActivity_Facebook
import com.dragboo.videodownload.adapters.RecyclerAdapter_Facebook.ViewHolder
import com.dragboo.videodownload.data.FilesData_Facebook
import com.dragboo.videodownload.filesoperations.FileOperation_Facebook
import com.unity3d.ads.UnityAds

import java.io.File
import java.util.ArrayList

class RecyclerAdapter_Facebook(myDataset: ArrayList<File>, private val mContext: Context, private val contentType: Char) : RecyclerView.Adapter<ViewHolder>() {
    private var mDataset: ArrayList<File>? = ArrayList()

    init {
        mDataset = myDataset
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val v: CardView
        if (mDataset != null && !mDataset!!.isEmpty()) {
            v = LayoutInflater.from(parent.context).inflate(R.layout.st_recyclerview_video_item, parent, false) as CardView
        } else {
            v = LayoutInflater.from(parent.context).inflate(R.layout.st_empty_warning, parent, false) as CardView
            val textView = v.findViewById<View>(R.id.textView) as TextView
            textView.text = "No video download yet"
        }
        return ViewHolder(v)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        if (mDataset != null) {
            if (!mDataset!!.isEmpty()) {
                Glide.with(mContext)
                        .load(mDataset!![position].path)
                        .override(600, 400)
                        .centerCrop()
                        .into(holder.mImageView!!)

                holder.mImageView.setOnClickListener {
                    val i = Intent(mContext, VideoViewerActivity_Facebook::class.java)
                    i.putExtra("position", position)
                    mContext.startActivity(i)
                }
                holder.shareButton!!.setOnClickListener { FileOperation_Facebook.shareFile(mDataset!![position], mContext, contentType) }

                holder.saveOrDelete!!.text = mContext.getString(R.string.delete)
                holder.saveOrDelete.setOnClickListener {
                    FileOperation_Facebook.deleteAndRefreshFiles(FilesData_Facebook.savedFilesVideos[position])
                    mDataset = FilesData_Facebook.savedFilesVideos
                    RecyclerInstances_Facebook.savedVideoAdapter!!.notifyDataSetChanged()
                    RecyclerInstances_Facebook.savedVideoRecyclerview!!.adapter = RecyclerInstances_Facebook.savedVideoAdapter
                }
            }
        }
    }

    override fun getItemCount(): Int {
        return if (mDataset != null) {
            if (mDataset!!.isEmpty()) {
                1

            } else {
                mDataset!!.size
            }
        } else {
            0
        }
    }

    inner class ViewHolder(v: CardView) : RecyclerView.ViewHolder(v) {
        val mImageView: ImageView? = v.findViewById(R.id.vvr)
        val shareButton: Button? = v.findViewById(R.id.sharefilebutton)
        val saveOrDelete: Button? = v.findViewById(R.id.saveORdelete)
    }
}