package com.dragboo.videodownload.adapters

import androidx.recyclerview.widget.RecyclerView

object RecyclerInstances_Instagram {
    var savedImageAdapter: RecyclerView.Adapter<*>? = null
    var savedVideoAdapter: RecyclerView.Adapter<*>? = null
    var savedImageRecyclerview: RecyclerView? = null
    var savedVideoRecyclerview: RecyclerView? = null
}