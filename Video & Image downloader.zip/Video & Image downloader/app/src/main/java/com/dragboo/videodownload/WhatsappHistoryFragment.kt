package com.dragboo.videodownload

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentStatePagerAdapter
import androidx.viewpager.widget.ViewPager
import com.dragboo.videodownload.data.FilesData
import com.dragboo.videodownload.fragments.ImageFragment
import com.dragboo.videodownload.fragments.VideoFragment
import com.google.android.material.tabs.TabLayout
import java.util.*

class WhatsappHistoryFragment : androidx.fragment.app.Fragment() {
    //    private var view: View? = null
    private var root: View? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
//        if (view == null) {
        root=inflater.inflate(R.layout.whatsapp_history, container, false)
            requestStoragePermission()
            childFragmentManager
            val mSectionsPagerAdapter = SectionsPagerAdapter(activity!!.supportFragmentManager)
            val mViewPager = root!!.findViewById<ViewPager>(R.id.container_whatsapp)
            mViewPager.adapter = mSectionsPagerAdapter
            val tabLayout = root!!.findViewById<TabLayout>(R.id.tabs_whatsapp)
            mViewPager.addOnPageChangeListener(TabLayout.TabLayoutOnPageChangeListener(tabLayout))
            tabLayout.addOnTabSelectedListener(TabLayout.ViewPagerOnTabSelectedListener(mViewPager))
//        }
        return root
    }

    inner class SectionsPagerAdapter(fm: FragmentManager) : FragmentStatePagerAdapter(fm) {
        private val fragments = ArrayList<Fragment>()
        private val fragmentNames = ArrayList<String>()

        init {
            fragments.clear()
            fragments.add(ImageFragment())
            fragmentNames.add(getString(R.string.tab_image))
            fragments.add(VideoFragment())
            fragmentNames.add(getString(R.string.tab_video))
        }

        override fun getItem(position: Int): Fragment {
            return fragments[position]
        }

        override fun getCount(): Int {
            return 2
        }

        override fun getPageTitle(position: Int): CharSequence? {
            return fragmentNames[position]
        }
    }

    private fun requestStoragePermission() {
        if (Build.VERSION.SDK_INT >= 23) {
            val permissions = arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
            if (ContextCompat.checkSelfPermission(context!!,
                            Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(activity!!, permissions, 123)
            } else {
                goToSavedStoriesTab()
            }
        } else {
            goToSavedStoriesTab()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions!!, grantResults)
        if (requestCode == 123) {
            if (grantResults.size != 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                goToSavedStoriesTab()
            }
        } else {
            Toast.makeText(context, getString(R.string.if_not_permitted), Toast.LENGTH_SHORT).show()
        }
    }

    private fun goToSavedStoriesTab() {
        FilesData.scrapSavedFiles()
        FilesData.recentOrSaved = "saved"
    }

//    override fun setUserVisibleHint(isVisibleToUser: Boolean) {
//        super.setUserVisibleHint(isVisibleToUser)
//        if (isVisibleToUser) {
//            // Refresh your fragment here
//            fragmentManager!!.beginTransaction().detach(this).attach(this).commit()
//            Log.i("IsRefresh", "Yes")
//        }
//    }
}