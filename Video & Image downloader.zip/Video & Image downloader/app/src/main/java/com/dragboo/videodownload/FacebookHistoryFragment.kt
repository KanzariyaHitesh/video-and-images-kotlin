package com.dragboo.videodownload

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.dragboo.videodownload.adapters.RecyclerAdapter_Facebook
import com.dragboo.videodownload.adapters.RecyclerInstances_Facebook
import com.dragboo.videodownload.data.FilesData_Facebook

class FacebookHistoryFragment : androidx.fragment.app.Fragment() {
//    private var view: View? = null
private var root: View? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
//        if (view == null) {
        root= inflater.inflate(R.layout.st_video_image_fragment, container, false)
            RecyclerInstances_Facebook.savedVideoRecyclerview = root!!.findViewById(R.id.videoImageRecyclerView)
            RecyclerInstances_Facebook.savedVideoRecyclerview!!.setHasFixedSize(true)
            val mLayoutManager = LinearLayoutManager(context)
            RecyclerInstances_Facebook.savedVideoRecyclerview!!.layoutManager = mLayoutManager
            if (FilesData_Facebook.savedFilesVideos.isEmpty()) {
                FilesData_Facebook.scrapSavedFiles()
            }
            RecyclerInstances_Facebook.savedVideoAdapter = RecyclerAdapter_Facebook(FilesData_Facebook.savedFilesVideos, requireContext(), 'v')
            RecyclerInstances_Facebook.savedVideoRecyclerview!!.adapter = RecyclerInstances_Facebook.savedVideoAdapter
//        }
        return root
    }

    override fun setUserVisibleHint(isVisibleToUser: Boolean) {
        super.setUserVisibleHint(isVisibleToUser)
        if (isVisibleToUser) {
            // Refresh your fragment here
            fragmentManager!!.beginTransaction().detach(this).attach(this).commit()
            Log.i("IsRefresh", "Yes")
        }
    }
}