package com.dragboo.videodownload

import android.annotation.SuppressLint
import android.app.Dialog
import android.app.DownloadManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.CountDownTimer
import android.os.Environment
import android.preference.PreferenceManager
import android.util.Log
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.CookieSyncManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.ProgressBar
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.fragment.app.Fragment
import java.io.File

class FacebookFragment : Fragment() {
//    private var view: View? = null
private var root: View? = null
    internal lateinit var bar: ProgressBar
    internal lateinit var progressBar: ProgressBar
    private var countDownTimer: CountDownTimer? = null
    internal lateinit var prefs: SharedPreferences
    private var timerHasStarted = false
    internal var id: Long = 0
    internal var onDownloadComplete: BroadcastReceiver? = null
    internal lateinit var pendingIntent: PendingIntent
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    @SuppressLint("NewApi")
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
//        if (view == null) {
        root = inflater.inflate(R.layout.facebook_fragment, container, false)
            progressBar = root!!.findViewById<View>(R.id.progressbar) as ProgressBar

            progressBar.visibility = View.VISIBLE
            webView = root!!.findViewById<View>(R.id.webView) as WebView
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                webView.settings.mediaPlaybackRequiresUserGesture = true
            }

            this.prefs = PreferenceManager.getDefaultSharedPreferences(context)
            this.countDownTimer = MyCountDownTimer(60000, 1000)
            if (timerHasStarted == false) {
                this.countDownTimer!!.start()
                this.timerHasStarted = true
            } else {
                this.countDownTimer!!.cancel()
                this.timerHasStarted = java.lang.Boolean.parseBoolean(null)
            }
            this.bar = root!!.findViewById<View>(R.id.load) as ProgressBar
            webView.settings.javaScriptEnabled = true
            webView.addJavascriptInterface(FBDownloader(requireContext()), "FBDownloader")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                webView.settings.mediaPlaybackRequiresUserGesture = true
            }
            webView.webViewClient = MyWebView()
            webView.setOnKeyListener(OnKeyChange())
            webView.setWebChromeClient(CromeWebView())
            webView.settings.domStorageEnabled = true
            webView.settings.setSupportZoom(true)
            webView.settings.savePassword = false
            webView.settings.builtInZoomControls = true
            webView.settings.displayZoomControls = true
            CookieSyncManager.createInstance(context)
            CookieManager.getInstance().setAcceptCookie(true)
            CookieSyncManager.getInstance().startSync()
            webView.loadUrl("https://m.facebook.com/")
//        }
        return root
    }

    internal inner class MyWebView : WebViewClient() {
        override fun onLoadResource(webView: WebView, str: String) {

            FacebookFragment.webView.loadUrl("javascript:(function prepareVideo() { var el = document.querySelectorAll('div[data-sigil]');for(var i=0;i<el.length; i++){var sigil = el[i].dataset.sigil;if(sigil.indexOf('inlineVideo') > -1){delete el[i].dataset.sigil;console.log(i);var jsonData = JSON.parse(el[i].dataset.store);el[i].setAttribute('onClick', 'FBDownloader.processVideo(\"'+jsonData['src']+'\",\"'+jsonData['videoID']+'\");');}}})()")
            //            FacebookFragment.webView.loadUrl("javascript: (function prepareVideo() {console.log('processVideo');var t = document.querySelectorAll('[data-sigil=\"m-stories-thread-media\"]'); for (var i = 0; i < t.length; i++) { var lang = t[i];var user = lang.childNodes[1];if (user.hasChildNodes()) {FBDownloader.processVideo('null');  } else {FBDownloader.processVideo(user.getAttribute('src').toString());}}})()");
            //            FacebookFragment.webView.loadUrl("javascript:( window.onload=prepareVideo;)()");
            FacebookFragment.webView.loadUrl("javascript:( window.onload=prepareVideo;)()")
        }

        override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
            progressBar.visibility = View.GONE
            super.onPageStarted(view, url, favicon)
        }

        override fun onPageFinished(webView: WebView, str: String) {
            FacebookFragment.webView.loadUrl("javascript:(function() { var el = document.querySelectorAll('div[data-sigil]');for(var i=0;i<el.length; i++){var sigil = el[i].dataset.sigil;if(sigil.indexOf('inlineVideo') > -1){delete el[i].dataset.sigil;var jsonData = JSON.parse(el[i].dataset.store);el[i].setAttribute('onClick', 'FBDownloader.processVideo(\"'+jsonData['src']+'\");');}}})()")
            //            FacebookFragment.webView.loadUrl("javascript: (function() {function prepareVideo() {console.log('processVideo');var t = document.querySelectorAll('[data-sigil=\"m-stories-thread-media\"]'); for (var i = 0; i < t.length; i++) { var lang = t[i];var user = lang.childNodes[1];if (user.hasChildNodes()) {FBDownloader.processVideo('null');  } else {FBDownloader.processVideo(user.getAttribute('src').toString());}}})()");
            Log.e("WEBVIEWFIN", str)
        }

        override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
            if (!url.startsWith("intent")) {
                view.loadUrl(url)
            }
            return true
        }
    }

    internal inner class OnKeyChange : View.OnKeyListener {
        override fun onKey(view: View, i: Int, keyEvent: KeyEvent): Boolean {
            if (keyEvent.action == 0) {
                val webView = view as WebView
                if (i == 4) {
                    if (webView.canGoBack() != false) {
                        webView.goBack()
                        return true
                    }
                }
            }
            return false
        }
    }

    internal inner class CromeWebView : WebChromeClient() {
        override fun onProgressChanged(webView: WebView, i: Int) {
            super.onProgressChanged(webView, i)
            if (i == 100) {
                bar.visibility = View.GONE
            } else {
                bar.visibility = View.GONE
            }
        }
    }

    inner class FBDownloader internal constructor(internal var mContext: Context) {
        @JavascriptInterface
        fun processVideo(str: String, str2: String) {
            Log.e("vid_data", str)
            Log.e("vid_id", str2)
            val dialog = Dialog(context!!)
            dialog.requestWindowFeature(1)
            dialog.window!!.setBackgroundDrawable(ColorDrawable(0))
            dialog.setContentView(R.layout.download_alert)
            dialog.show()
            val button = dialog.findViewById<View>(R.id.button_download) as Button
            val button2 = dialog.findViewById<View>(R.id.button_cancel) as Button
            (dialog.findViewById<View>(R.id.button_watch) as Button).setOnClickListener {
                this@FacebookFragment.streamFB(str)
                //                    Toast.makeText(getContext(), "Streaming Started", Toast.LENGTH_LONG).show();
                dialog.dismiss()
            }
            button.setOnClickListener(object : View.OnClickListener {
                internal inner class Run : Runnable {
                    override fun run() {
                        //                        showInterstitial();
                    }
                }

                override fun onClick(view: View) {
                    this@FacebookFragment.activity!!.runOnUiThread(Run())
                    this@FacebookFragment.downloadFB(str, str2)
                    dialog.dismiss()
                }
            })
            button2.setOnClickListener { dialog.dismiss() }
        }
    }

    @SuppressLint("WrongConstant", "NewApi")
    fun downloadFB(str: String, str2: String) {
        var str2 = str2
        try {
            val stringBuilder = StringBuilder()
            stringBuilder.append(Environment.getExternalStorageDirectory())
            stringBuilder.append(File.separator)
            stringBuilder.append("Video and Image Download/Facebook Video")
            stringBuilder.append(File.separator)
            val stringBuilder2 = stringBuilder.toString()
            if (!File(stringBuilder2).exists()) {
                File(stringBuilder2).mkdir()
            }
            val stringBuilder3 = StringBuilder("file://")
            stringBuilder3.append(stringBuilder2)
            stringBuilder3.append("/")
            stringBuilder3.append(str2)
            stringBuilder3.append(".mp4")
            str2 = stringBuilder3.toString()
            val request = DownloadManager.Request(Uri.parse(str))
            request.setDestinationUri(Uri.parse(str2))
            val intent = Intent(activity, MainActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            intent.putExtra("From", "notifyFrag")
            pendingIntent = PendingIntent.getActivity(context, 0, intent, 0)
            activity
            val mgr = activity!!.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            id = mgr.enqueue(request)
            onDownloadComplete = object : BroadcastReceiver() {
                override fun onReceive(context: Context, intent: Intent) {
                    //Fetching the download id received with the broadcast
                    val ids = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1)
                    //Checking if the received broadcast is for our enqueued download by matching download id
                    if (id == ids) {
                        //                        Toast.makeText(getContext(), "Download Completed", Toast.LENGTH_SHORT).show();
                        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                            count = 1 + count
                            val mNotificationManager = activity!!.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                            val mBuilder = NotificationCompat.Builder(getContext())
                                    .setSmallIcon(R.drawable.app_icon)
                                    .setContentTitle("Video has been downloaded")
                                    .setContentText("Facebook")
                                    .setAutoCancel(true)
                                    .setNumber(count)
                                    .setDefaults(0)
                            mBuilder.setContentIntent(pendingIntent)
                                    .build()

                            val importance = NotificationManager.IMPORTANCE_HIGH
                            val notificationChannel = NotificationChannel(NOTIFICATION_CHANNEL_ID, "NOTIFICATION_CHANNEL_NAME", importance)
                            notificationChannel.enableLights(true)
                            notificationChannel.lightColor = Color.RED
                            notificationChannel.enableVibration(true)
                            notificationChannel.vibrationPattern = longArrayOf(100, 200, 300, 400, 500, 400, 300, 200, 400)
                            assert(mNotificationManager != null)
                            mBuilder.setChannelId(NOTIFICATION_CHANNEL_ID)
                            mNotificationManager.createNotificationChannel(notificationChannel)
                            assert(mNotificationManager != null)
                            mNotificationManager.notify(0 /* Request Code */, mBuilder.build())
                        } else {
                            count = 1 + count
                            val mBuilder = NotificationCompat.Builder(getContext())
                                    .setSmallIcon(R.drawable.app_icon)
                                    .setContentTitle("Video has been downloaded")
                                    .setContentText("Facebook")
                                    .setAutoCancel(true)
                                    .setNumber(count)
                                    .setDefaults(0)
                            mBuilder.setContentIntent(pendingIntent)
                            val notificationManager = activity!!.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                            notificationManager.notify(0, mBuilder.build())
                        }
                    }
                }
            }
            activity!!.registerReceiver(onDownloadComplete, IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE))
            Toast.makeText(context, "Added to Download Queue", Toast.LENGTH_LONG).show()
        } catch (str3: Exception) {
            Log.e("Error", str3.message)
            Toast.makeText(context, "Download Failed", Toast.LENGTH_LONG).show()
        }

    }


    fun streamFB(str: String) {
        try {
            val intent = Intent(context, StreamVideo::class.java)
            intent.putExtra("video_url", str)
            startActivity(intent)
            //            Toast.makeText(getContext(), "Streaming Started", Toast.LENGTH_LONG).show();
        } catch (str2: Exception) {
            Log.e("Error", str2.message)
            Toast.makeText(context, "Streaming Failed", Toast.LENGTH_LONG).show()
        }

    }

    inner class MyCountDownTimer(j: Long, j2: Long) : CountDownTimer(j, j2) {
        override fun onFinish() {}
        override fun onTick(j: Long) {}
    }
    //    public void showInterstitial() {
    //        getActivity().runOnUiThread(new Runnable() {
    //            public void run() {
    //                if (MainActivity.mInterstitialAd == null || !MainActivity.mInterstitialAd.isLoaded()) {
    //                    interstitialAd = new InterstitialAd(getContext());
    //                    interstitialAd.setAdUnitId(getString(R.string.ad_intert_id));
    //                    interstitialAd.loadAd(new AdRequest.Builder().build());
    //                    interstitialAd.setAdListener(new LoadAds());
    //                    return;
    //                }
    //                else {
    //                    //Log.d(TAG, "Interstitial ad is not loaded yet");
    //                }
    //                MainActivity.mInterstitialAd.show();
    //            }
    //        });
    //}
    //    private class LoadAds extends AdListener {
    //        LoadAds() { }
    //        public void onAdLoaded() {
    //            if (interstitialAd != null && interstitialAd.isLoaded()) {
    //                interstitialAd.show();
    //            }
    //        }

    //        public void onAdFailedToLoad(int errorCode) {
    ////            Toast.makeText(getContext(), "ads Load Failed"+errorCode, Toast.LENGTH_LONG).show();
    //        }
    //        public void onAdOpened() {
    ////            Toast.makeText(getContext(), "ads Load Successfully", Toast.LENGTH_LONG).show();
    //        }
    //        public void onAdLeftApplication() { }
    //        public void onAdClosed() { }
    //    }
    override fun onDestroy() {
        try {
            if (onDownloadComplete != null)
                activity!!.unregisterReceiver(onDownloadComplete)
        } catch (e: Exception) {
        }

        super.onDestroy()
    }

    companion object {
        internal lateinit var webView: WebView
        //    private InterstitialAd interstitialAd;
        private var count = 0
        private val NOTIFICATION_CHANNEL_ID = "notification_channel_id"
    }
}