package com.dragboo.videodownload.data

import android.os.Environment
import org.apache.commons.io.comparator.LastModifiedFileComparator.*
import java.io.File
import java.util.ArrayList
import java.util.Arrays

object FilesData_Facebook {
    private val SAVED_FILES_LOCATION = "/Video and Image Download/Facebook Video"
    val savedFilesImages = ArrayList<File>()
    val savedFilesVideos = ArrayList<File>()

    fun scrapSavedFiles() {
        savedFilesImages.clear()
        savedFilesVideos.clear()
        val files: Array<File>?
        val parentDir = File(Environment.getExternalStorageDirectory().toString() + SAVED_FILES_LOCATION)
        if (!parentDir.exists())
            parentDir.mkdirs()
        files = parentDir.listFiles()
        Arrays.sort(files!!, LASTMODIFIED_REVERSE)
        if (files != null) {
            for (file in files) {
                if (file.name.endsWith(".jpg")) {
                    if (!savedFilesImages.contains(file))
                        savedFilesImages.add(file)
                } else if (file.name.endsWith(".gif") || file.name.endsWith(".mp4")) {
                    if (!savedFilesVideos.contains(file))
                        savedFilesVideos.add(file)
                }
            }
        }
    }
}