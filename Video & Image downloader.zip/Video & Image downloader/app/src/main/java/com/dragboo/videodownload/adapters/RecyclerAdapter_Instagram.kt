package com.dragboo.videodownload.adapters

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.dragboo.videodownload.ImageViewerActivity_Instagram
import com.dragboo.videodownload.R
import com.dragboo.videodownload.VideoViewerActivity_Instagram
import com.dragboo.videodownload.data.FilesData_Instagram
import com.dragboo.videodownload.filesoperations.FileOperation_Instagram
import java.io.File
import java.util.ArrayList

class RecyclerAdapter_Instagram(myDataset: ArrayList<File>, private val mContext: Context, private val contentType: Char) : RecyclerView.Adapter<RecyclerAdapter_Instagram.ViewHolder>() {
    private var mDataset: ArrayList<File>? = ArrayList()

    init {
        mDataset = myDataset
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val v: CardView
        if (mDataset != null && !mDataset!!.isEmpty()) {
            if (contentType == 'i') {
                v = LayoutInflater.from(parent.context)
                        .inflate(R.layout.st_recyclerview_image_item, parent, false) as CardView
            } else {
                v = LayoutInflater.from(parent.context).inflate(R.layout.st_recyclerview_video_item, parent, false) as CardView
            }
        } else {
            v = LayoutInflater.from(parent.context).inflate(R.layout.st_empty_warning, parent, false) as CardView
            if (contentType == 'i') {
                val textView = v.findViewById<View>(R.id.textView) as TextView
                textView.text = "No image download yet"
            } else {
                val textView = v.findViewById<View>(R.id.textView) as TextView
                textView.text = "No video download yet"
            }
        }
        return ViewHolder(v)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        if (mDataset != null) {
            if (!mDataset!!.isEmpty()) {
                if (contentType == 'i') {
                    Glide.with(mContext)
                            .load(mDataset!![position].path)
                            .override(600, 400)
                            .centerCrop()
                            .into(holder.mImageView!!)

                    holder.mImageView.setOnClickListener {
                        val i = Intent(mContext, ImageViewerActivity_Instagram::class.java)
                        i.putExtra("path", mDataset!![position].path)
                        mContext.startActivity(i)
                    }
                } else {
                    Glide.with(mContext)
                            .load(mDataset!![position].path)
                            .override(600, 400)
                            .centerCrop()
                            .into(holder.mImageView!!)

                    holder.mImageView.setOnClickListener {
                        val i = Intent(mContext, VideoViewerActivity_Instagram::class.java)
                        i.putExtra("position", position)
                        mContext.startActivity(i)
                    }
                }
                holder.shareButton!!.setOnClickListener { FileOperation_Instagram.shareFile(mDataset!![position], mContext, contentType) }

                holder.saveOrDelete!!.text = mContext.getString(R.string.delete)
                holder.saveOrDelete.setOnClickListener {
                    if (contentType == 'i') {

                        FileOperation_Instagram.deleteAndRefreshFiles(FilesData_Instagram.savedFilesImages[position])
                        mDataset = FilesData_Instagram.savedFilesImages
                        RecyclerInstances_Instagram.savedImageAdapter!!.notifyDataSetChanged()
                        RecyclerInstances_Instagram.savedImageRecyclerview!!.adapter = RecyclerInstances_Instagram.savedImageAdapter
                    } else {
                        FileOperation_Instagram.deleteAndRefreshFiles(FilesData_Instagram.savedFilesVideos[position])
                        mDataset = FilesData_Instagram.savedFilesVideos
                        RecyclerInstances_Instagram.savedVideoAdapter!!.notifyDataSetChanged()
                        RecyclerInstances_Instagram.savedVideoRecyclerview!!.adapter = RecyclerInstances_Instagram.savedVideoAdapter
                    }
                }
            }
        }
    }

    override fun getItemCount(): Int {
        return if (mDataset != null) {
            if (mDataset!!.isEmpty()) {
                1
            } else {
                mDataset!!.size
            }
        } else {
            0
        }
    }

    inner class ViewHolder(v: CardView) : RecyclerView.ViewHolder(v) {
        val mImageView: ImageView?
        val shareButton: Button?
        val saveOrDelete: Button?

        init {
            mImageView = v.findViewById(R.id.vvr)
            shareButton = v.findViewById(R.id.sharefilebutton)
            saveOrDelete = v.findViewById(R.id.saveORdelete)
        }
    }
}