package com.dragboo.videodownload.update

import retrofit2.Call
import retrofit2.http.POST

interface ApiInterface {
    @POST("index")
    fun getupdate(): Call<ResponseData>
}
